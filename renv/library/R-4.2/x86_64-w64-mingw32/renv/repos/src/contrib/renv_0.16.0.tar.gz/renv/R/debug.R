
renv_debugging <- function() {
  getOption("renv.debugging", default = FALSE)
}
